CREATE DATABASE celebal_week7;
USE  celebal_week7;
DROP TABLE IF EXISTS CUST_MSTR;

CREATE TABLE CUST_MSTR (
    cust_id INT PRIMARY KEY,
    name VARCHAR(100),
    region VARCHAR(50),
    date DATE
);


DROP TABLE IF EXISTS master_child;

CREATE TABLE master_child (
    parent_id INT,
    child_id INT,
    relation VARCHAR(50),
    date DATE,
    date_key VARCHAR(20)
);

DROP TABLE IF EXISTS H_ECOM_Orders;

CREATE TABLE H_ECOM_Orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    amount DECIMAL(10, 2)
);
SELECT * FROM CUST_MSTR;
SELECT * FROM master_child;
SELECT * FROM H_ECOM_Orders;

