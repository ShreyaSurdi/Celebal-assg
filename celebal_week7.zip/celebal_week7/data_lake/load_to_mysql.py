import os
import pandas as pd
from sqlalchemy import create_engine, text

# Database connection setup
user = 'root'
password = 'Admin@0218'
host = 'localhost'
port = '3306'
database = 'celebal_week7'

engine = create_engine(f'mysql+pymysql://root:Admin%400218@localhost:3306/celebal_week7')

# Folder path
folder_path = '.'


# Process each file
for filename in os.listdir(folder_path):
    filepath = os.path.join(folder_path, filename)

    if filename.startswith("CUST_MSTR"):
        # Extract date from filename
        date_str = filename.split("_")[2].split(".")[0]
        formatted_date = f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:]}"
        
        # Read CSV and add new column
        df = pd.read_csv(filepath)
        df['date'] = formatted_date

        with engine.begin() as conn:
            conn.execute(text("TRUNCATE TABLE CUST_MSTR"))
            df.to_sql('CUST_MSTR', con=conn, if_exists='append', index=False)
        print(f"✅ Loaded {filename} into CUST_MSTR")

    elif filename.startswith("master_child_export"):
        date_part = filename.split("-")[1].split(".")[0]
        formatted_date = f"{date_part[:4]}-{date_part[4:6]}-{date_part[6:]}"
        date_key = date_part

        df = pd.read_csv(filepath)
        df['date'] = formatted_date
        df['date_key'] = date_key

        with engine.begin() as conn:
            conn.execute(text("TRUNCATE TABLE master_child"))
            df.to_sql('master_child', con=conn, if_exists='append', index=False)
        print(f"✅ Loaded {filename} into master_child")

    elif filename.startswith("H_ECOM_ORDER"):
        df = pd.read_csv(filepath)

        with engine.begin() as conn:
            conn.execute(text("TRUNCATE TABLE H_ECOM_Orders"))
            df.to_sql('H_ECOM_Orders', con=conn, if_exists='append', index=False)
        print(f"✅ Loaded {filename} into H_ECOM_Orders")

    else:
        print(f"⚠️ Skipping unknown file: {filename}")
